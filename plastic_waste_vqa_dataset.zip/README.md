# Plastic Waste Bilingual VQA Dataset

Generated from the supplied Dataset.zip using the supplied VQA specification.

## Files
- plastic_waste_vqa_bilingual.json
- plastic_waste_vqa_train.json
- plastic_waste_vqa_validation.json
- plastic_waste_vqa_test.json
- plastic_waste_vqa_quality_report.json
- plastic_waste_vqa_bilingual.csv

## Summary
- Images: 402
- Base/original groups: 136
- QA pairs: 2412
- English: 1206
- Bangla: 1206
- Train/Validation/Test images: 282/58/62
- Exact duplicate questions remaining: 0

## Label interpretation
No class-name mapping file was present in the archive. Numeric YOLO classes were conservatively mapped after visual review of representative images: 0=bottle, 1=cup, 2=wrapper/packaging, 3=straw, 4=bag/sheet. Labels were treated as supplementary to the image evidence.

## Leakage control
Augmented variants sharing the same source_base_id are kept in the same split.
